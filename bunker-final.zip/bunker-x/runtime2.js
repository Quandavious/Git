function log(m,l){
	if(l=="w"){
		console.warn("[WARNING]: "+m);
	} else if (l=="e"){
		console.error("[ERROR]: "+m);
	} else {
		console.log(m);
	}
}
log("Core initialized");
var data;
async function forkCompletion(a,b){
	if(b!="def"){
		console.log(getDeepKeys(b).length); data=b;
	} else{
		if(window.__default != undefined){
			data=window.__default;
			localStorage.profile = JSON.stringify(data);
		} else {
			a.innerHTML = a.innerHTML+"<br>Failed to retrieve default system image...";
			setTimeout(boot, 4000);
			throw "reboot";
		}
	}
	a.innerHTML = a.innerHTML+"<br>Loading profile data";
	a.innerHTML = a.innerHTML+"<br>Starting User Interface";
	setTimeout(initMain, 500);
	(async function(){
		var kdmkk4 = JSON.stringify(data);
		setInterval(function(){
			if(JSON.stringify(data) != kdmkk4){
				localStorage.profile = JSON.stringify(data);
				console.log("-- ALERT mk2 f4 -- SAVED TO LOCAL STORAGE");
				kdmkk4 = JSON.stringify(data);
			}
		}, 1000);
	})();
}

function forkExtension(){
	var input = document.createElement('input');
	input.accept = ".json";
	input.type = 'file';
	input.onchange = e => {
	   var file = e.target.files[0]; 
	   var reader = new FileReader();
	   reader.readAsText(file,'UTF-8');
	   reader.onload = readerEvent => {
		  var content = readerEvent.target.result;
		  var out = undefined;
		  try{
			  out = JSON.parse(content);
		  }catch(e){
			  document.getElementById("boot_content").innerHTML = document.getElementById("boot_content").innerHTML+"<br>Import failed...";
			  setTimeout(boot, 4000);
			  return "reboot";
		  }
		  if(out!=undefined&&out["bunker"] == true){
			  forkCompletion(document.getElementById("boot_content"), out);
		  }
	   }
	}
	input.click();
}
async function boot(){
	var a = document.getElementById("boot_content");
	a.innerHTML = "Bunker 10<br>JavaScythe and the Math Study Group team";
	a.innerHTML = a.innerHTML+"<br><br>Loading started";
	a.innerHTML = a.innerHTML+"<br>Complete network checks";
	a.innerHTML = a.innerHTML+"<br>Importing profile";
	//forkCompletion(a, "def");
	//return false;
	if(localStorage.profile == undefined){
		a.innerHTML = a.innerHTML+"<br>WARN: no system image found<br>Import one manually (y) or use default configuration? (n) (type y/n):";
		a.innerHTML = a.innerHTML+`<br><input style="width:40vw;" id="ynimp">`;
		document.getElementById("ynimp").addEventListener("keypress", function(e){
			if(e.code == "Enter"){
				var t = document.getElementById("ynimp").value;
				if(t == "y"){
					forkExtension(a);
				} else if(t == "n"){
					forkCompletion(a, "def");
				} else {
					forkExtension(a);
				}
				e.preventDefault();
			}
		})
		document.getElementById("ynimp").focus();
	} else {
		//console.log(localStorage.profile);
		forkCompletion(a,JSON.parse(localStorage.profile));	
	}
	console.log("exited bootloop");
};
boot();
const initBody = `<!DOCTYPE html><html><head><title>null</title></head><body><p id="p"></p><script>#startj#</script><script>#indexfire#</script></body></html>`;
var engine = {};
engine.apps = {};
engine.events = {};
engine.process = [];
engine.processes = {};
engine.processes.register = function(src, content, name, parent, icon, app, start){
	var sid = createUUID();
	engine.process.push({
		sid: sid,
		source: src,
		parent: parent || null,
		content: content,
		name: name || sid+".exp",
		active: false,
		gui: false,
		inTray: false,
		icon: icon || "https://wallpapercave.com/wp/wp7304269.jpg",
		contextOptions: {},
		appPointer: app || undefined,
		start: start || {}
	});
	var f = document.createElement("iframe");
	f.setAttribute("id", sid);
	f.setAttribute("src", "about:blank");
	f.setAttribute("style", "display:none;");
	f.onload = function() {
		var ss = "";
		if(start != undefined){
			console.log("------ ALERT ------ Applied StartScript to new process")
			ss = "window.__start = "+JSON.stringify(start);
		}
		engine.modify(sid).contentWindow.window.document.write(initBody.replace("#startj#", `${ss}`).replace("#indexfire#", content["/index.js"]));
    }
	engine.modify("appContent").appendChild(f);
}
engine.processes.getProcessBySid = function(sid,t){
	for(var i in engine.process){
		if(engine.process[i]["sid"] == sid){
			if(t == undefined || t == "p") return engine.process[i];
			if(t == "i") return i;
		}
	}
	return undefined;
}
engine.create = function(html){
	var d = document.createElement("div");
	d.innerHTML = html;
	return d.children[0];
}
engine.apps.active = {};
engine.apps.showHome = function(){
	engine.modify("mainAppArea").style.display = "none";
	engine.modify("subArea").style.display = "block";
}
engine.apps.handleControl = function(id){
	if(id == 0){ //minimize
		var p = engine.process;
		for(var i in p){
			if(p[i].active){
				console.log(p[i]);
				engine.process[i].active = false;
			}
			engine.apps.showHome();
		}
	} else if (id == 2){
		var p = engine.process;
		for(var i in p){
			if(p[i].active){
				engine.apps.destroy(p[i].sid);
			}
			engine.apps.showHome();
		}
	}
}
engine.apps.refreshAppSubs = function(){
	var p = engine.process;
	for(var i in p){
		if(p[i].active){
			engine.modify(p[i].sid).style.display = "block";
		} else {
			engine.modify(p[i].sid).style.display = "none";
		}
	}
}
engine.apps.showActiveApp = function(){
	engine.apps.refreshAppSubs();
	engine.modify("mainAppArea").style.display = "block";
	engine.modify("subArea").style.display = "none";
}
engine.apps.launch = function(uid){
	engine.processes.register("userclick", data.apps[uid].virtualFileSystem, data.apps[uid].basicInfo.displayName, undefined, data.apps[uid].basicInfo.icon, uid);
}
engine.apps.subLaunch = function(uid, start){
	if(data.apps[uid] != undefined){
		engine.processes.register("userclick", data.apps[uid].virtualFileSystem, data.apps[uid].basicInfo.displayName, undefined, data.apps[uid].basicInfo.icon, uid, start);
	} else {
		engine.notification.generate("Failed to launch app", "No app with pointer '"+uid+"' found.", "system/apps/subLaunch");
	}
}
engine.apps.destroy = function(sid){
	var i = engine.processes.getProcessBySid(sid,"i");
	engine.process.splice(i,1);
	engine.modify(sid).parentElement.removeChild(engine.modify(sid));
	engine.gui.tray.refresh();
	engine.gui.taskbar.refresh();
}
engine.apps.display = function(){
	var a = "";
	if(data.apps["dev.bunker.settings"] != undefined){
		a=a+`<button onclick="engine.apps.launch('${data.apps["dev.bunker.settings"].basicInfo.pointer}')" class="appDiv"><img src="${data.apps["dev.bunker.settings"].basicInfo.icon}"><h4>${data.apps["dev.bunker.settings"].basicInfo.displayName}</h4></button>`
	}
	for(var i in data.apps){
		if(i == "dev.bunker.settings"){continue;};
		a=a+`<button onclick="engine.apps.launch('${data.apps[i].basicInfo.pointer}')" class="appDiv"><img src="${data.apps[i].basicInfo.icon}"><h4>${data.apps[i].basicInfo.displayName}</h4></button>`;
	}
	engine.modify("appArea").innerHTML = a;
}
engine.notification = {};
engine.modify = function(id){return document.getElementById(id)};
engine.notification.generate = function(title, text, source){
	if(data.settings.osManaged.allowGlobalNotifications == true){
		engine.system.executeEventMessage("notification", {t: title,t: text, s: source});
		engine.modify("notif").innerHTML = `<div class="notifWrap" onclick="this.style.opacity=0;"><h2>${title}</h2><p class="ntf">${text}</p><p class="nsr">${source}</p></div>`;
	}
}
function initMain(){
	log("main UI");
	engine.gui.applyTheming();
	document.getElementById("bootsplash").style.display = "none";
	engine.apps.display();
	document.getElementById("basicUi").style.display = "block";
	engine.notification.generate("Profile Data Imported", "successfully imported "+getDeepKeys(data).length+" items", "system");
}
engine.gui = {};
engine.gui.taskbar = {};
engine.gui.tray = {};
engine.gui.handleOut = function(){
	if(engine.utils.click != "2" && engine.gui.tray.contextOn){
		console.log(engine.utils.click)
		engine.gui.tray.contextOn = false;
		engine.modify("system-tray-context-menu").parentElement.removeChild(engine.modify("system-tray-context-menu"));
	} else {
		engine.utils.click = "";
	}
}
engine.gui.enterSplash = function(sid){
	engine.apps.handleControl(0);
	engine.process[engine.processes.getProcessBySid(sid,"i")]["active"] = true;
	engine.process[engine.processes.getProcessBySid(sid,"i")]["gui"] = true;
	engine.modify(sid).style.display = "block";
	engine.apps.showActiveApp();
}
engine.gui.tray.closeContext = function(){
	engine.gui.tray.contextOn = false;
	engine.modify("system-tray-context-menu").parentElement.removeChild(engine.modify("system-tray-context-menu"));
}
engine.gui.tray.contextMenu = function(e,el){
	if(engine.gui.tray.contextOn){e.preventDefault();return false;}
	var sid = el.id.split("-tra")[0];
	console.log(sid);
	var opts = engine.process[engine.processes.getProcessBySid(sid,"i")]["contextOptions"];
	engine.gui.tray.contextOn = true;
	var b = el.getBoundingClientRect();
	console.log(b.x);
	console.log(b.y);
	var d = document.createElement("div");
	d.setAttribute("style", "position:absolute;z-index:999;height:max-content;width:max-content;top:"+b.y+"px;left:"+b.x+"px;");
	d.setAttribute("onclick", "engine.utils.click='2'");
	d.setAttribute("id", "system-tray-context-menu");
	d.setAttribute("class", "ctxD");
	var op = "";
	for(var i in opts){
		var ro = {
			"type": "contextClick",
			"passed": opts[i]
		};
		ro=JSON.stringify(ro);
		op=op+`<button onclick="engine.gui.tray.closeContext();engine.system.react('${sid}',${ro});" class="ctxAc">${i}</button>`;
	}
	d.innerHTML = op+`<button onclick="engine.gui.tray.closeContext();engine.apps.destroy('${sid}');" class="ctxAc">End task</button>`
	document.body.appendChild(d);
	
	e.preventDefault();
	return false;
}
engine.gui.tray.contextOn = false;
engine.gui.taskbar.refresh = function(){
	var p = engine.process;
	var s = `<button title="defaultSystem" class="appMin"><img src="https://wallpapercave.com/wp/wp7304269.jpg"></button>`;
	for(i in p){
		if(p[i].gui){
			console.log(`created taskbar item with data `,p[i]);
			s += `<button onclick="engine.gui.enterSplash('${p[i].sid}');" title="${p[i].name}" class="appMin"><img src="${p[i].icon}"></button>`;
		}
	}
	engine.modify("appToolbar").innerHTML = s;
}
engine.gui.tray.refresh = function(){
	var p = engine.process;
	engine.modify("systray").innerHTML = `<span id="systime">6:18 AM - 5/14/2022 BUNKER 10</span>`;
	for(i in p){
		if(p[i].inTray == true && engine.modify(p[i].sid+"-tray") == undefined){
			engine.modify("systray").innerHTML = engine.modify("systray").innerHTML+`<span oncontextmenu="engine.gui.tray.contextMenu(event,this)" id="${p[i].sid}-tray"><img title="${p[i].name}" src="${p[i].icon}"></span>`;
			engine.modify(p[i].sid+"-tray").onmousedown = function(event) {
				var sid = this.id.split("-")[0];
				if (event.which == 3) {
					event.preventDefault();
					try{
					engine.processes.getProcessBySid(sid).onTrayRightClick();
					}catch(e){};
				} else if (event.which == 1){
					try{
					engine.processes.getProcessBySid(sid).onTrayLeftClick();
					}catch(e){};
				}
			}
		} else if(p[i].inTray == false && engine.modify(p[i].sid+"-tray") != undefined){
			engine.modify(p[i].sid+"-tray").parentElement.removeChild(engine.modify(p[i].sid+"-tray"));
		}
	}
}
engine.gui.applyTheming = function(){
	var st = document.createElement("style");
	for(var i in data.themes){
		if(data.themes[i].active == true){
			st.innerHTML = data.themes[i].file;
			console.log("found da ACTIVE FIRE theme :fire:")
		}
	}
	st.setAttribute("id", "bootStyling");
	document.head.appendChild(st);
	engine.modify("bootStyling").parentElement.removeChild(engine.modify("bootStyling"));
}
engine.utils = {};
engine.utils.gR = function(o,k){
	if(o){
		return {"ok": true, "code": k}
	} else {
		return {"ok": false, "code": k}
	}
}
engine.utils.click = "";
engine.events.list = {
	"notification": []
};
window.addEventListener("message", (event) => {
	console.log(event.source.frameElement.id+" posted event");
	var sid = event.source.frameElement.id;
	var d = event.data;
	var t = d.type;
	engine.system.interface(sid,d,t);
}, false);
engine.system = {};
engine.system.executeEventMessage = function(t,d){
	if(engine.events.list[t] == [] || engine.events.list[t] == undefined) return false;
	var a = engine.events.list[t];
	for(i in a){
		engine.system.react({
			"type": "event",
			"eventType": t,
			"payload": d || null
		}, a[i]);
	}
}
engine.system.react = function(m, t){
	console.log("posted event back to "+t+" with data :",m);
	engine.modify(t).contentWindow.postMessage(m);
}
engine.system.interface = function(sid, d, t){
	switch (t){
		case "notification":
			engine.notification.generate(d.title, d.text, engine.processes.getProcessBySid(sid)["name"]);
			engine.system.react(engine.utils.gR(1, 201),sid);
			break;
		case "upgradeGUI":
			engine.apps.handleControl(0);
			engine.gui.enterSplash(sid);
			engine.gui.taskbar.refresh();
			engine.system.react(engine.utils.gR(1, 201),sid);
			break;
		case "registerChildProcess":
			engine.processes.register(sid, d.content, d.name, sid);
			engine.system.react(engine.utils.gR(1,200), sid);
			break;
		case "forwardChildProcess":
			if(engine.processes.getProcessBySid(d.target)["parent"] == sid && engine.processes.getProcessBySid(sid)["children"].indexOf(d.target)){
				engine.system.react({"type":"forward","from": sid, "to": d.target, "forward":d.payload}, d.target);
			}else{
				engine.system.react(engine.utils.gR(0,403),sid);
			}
			break;
		case "kill":
			engine.modify(sid).parentElement.removeChild(engine.modify(sid));
			engine.process.splice(engine.processes.getProcessBySid(sid,"i"), 1);
			//obv no reaction because would fail since iframe is destroyed
			break;
		case "virtualFileSystemInterface":
			if(d.method == "GET"){
				var st = engine.processes.getProcessBySid(sid).content;
				if(st[d.path] != undefined){
					engine.system.react({"ok": true, code: 200, content: st[d.path], req: d}, sid);
				} else {
					engine.system.react({"ok": false, code: 404}, sid);
				}
			}else if(d.method == "POST"){
				if(typeof d.content != "string"){
					engine.system.react({"ok": false, code: 405}, sid);
				} else {
					data.apps[engine.processes.getProcessBySid(sid).appPointer][d.path] = d.content;
					engine.system.react(engine.utils.gR(1,202),sid);
				}
			}
			break;
		case "networkFetch":
			var net = data.settings.osManaged;
			if(net.network){
				if(net.networkRelay){
					
				} else {
					var kb;
					try{
						//kb = await fetch(d.url);
						//kb= await kb.text();
					}catch(e){
						engine.system.react(engine.utils.gR(0,404),sid);
						break;
					}
					engine.system.react({ok:true,code:200,content:kb,req:d},sid);
				}
			} else {
				engine.system.react(engine.utils.gR(0,403),sid);
				break;
			}
			break;
		case "registerEventListener":
			switch(d.eventType){
				case "notification":
					engine.events.list.notification.push(sid);
					engine.system.react(engine.utils.gR(1, 204),sid);
					break;
			}
			break;
		case "unregisterEventListener":
			switch(d.eventType){
				case "notification":
					if(engine.events.list.notification.indexOf(sid) != -1) engine.events.list.notification.splice(engine.events.list.notification.indexOf(sid), 1);
					engine.system.react(engine.utils.gR(1, 204),sid);
					break;
				
			}
			break;
		case "upgradeTray":
			engine.process[engine.processes.getProcessBySid(sid,"i")]["inTray"] = true;
			engine.system.react(engine.utils.gR(1, 201),sid);
			engine.gui.tray.refresh();
			break;
		case "registerContextOptions":
			engine.process[engine.processes.getProcessBySid(sid,"i")]["contextOptions"] = d.contextOptions;
			engine.system.react(engine.utils.gR(1, 201),sid);
			break;
		case "administrativeInterfaceRequest":
			var isA = data.apps[engine.processes.getProcessBySid(sid).appPointer].permissions.allowed.indexOf("administrativeApplication");
			if(isA != -1){
				console.log("evaluated administrative command (possible corruption or data loss could have occured)");
				eval(d.evaluate);
				engine.system.react(engine.utils.gR(1, 200), sid);
				
			}
			break;
	}
}